# OP TRADER AI V1.0 — Android Studio source

## Included in this prototype
- Kotlin + Jetpack Compose Android app
- Asset selector for Forex, crypto, stocks, commodities and OTC-labelled demo pairs
- Real Market / OTC demo mode selector
- 1-minute and 5-minute timeframe selector
- EMA 9/21/50, RSI(14), MACD and ATR(14) calculations
- Basic bullish/bearish engulfing pattern detection
- BUY / SELL / WAIT rule-based signal
- Explanation and caution lists
- Manual WIN / LOSS / BREAKEVEN journal (in-memory prototype)

## Important limitations
This is a functional UI and analysis-engine prototype using deterministic demo candles.
It does not fetch live data and is not connected to Quotex. Selecting an asset or timeframe
changes the demo seed, not a live feed. OTC prices are not represented as real broker OTC prices.
The score is a setup score, not a probability of winning. No automatic order placement exists.

## Build APK in Android Studio
1. Install Android Studio (a recent stable version) and Android SDK Platform 35.
2. Open this folder as an existing Gradle project.
3. Allow Gradle sync to complete. Android Studio will download the Gradle wrapper/build dependencies if needed.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

Command line (with JDK 17 and Android SDK installed):
`gradle assembleDebug`

## Next engineering milestones
- Connect licensed real-market OHLC feeds with clear source/timestamp labels.
- Design a separately verified OTC data integration; do not scrape broker sessions.
- Add persistent local trade journal, candle import, backtesting and fees/payout-aware expectancy.
- Add trade-by-trade outcome attribution and avoid look-ahead bias in backtests.
- Add exportable diagnostics and configurable alert thresholds.

## Project identity
Application ID: `com.optraderai.app`
Version: `1.0`
Minimum Android: 8.0 (API 26)
Target SDK: 35


## Build directly from an Android phone (cloud build)

You do not need Android Studio installed on your phone.

1. Download and extract this ZIP using your phone's file manager.
2. Create/sign in to a GitHub account at https://github.com.
3. In your mobile browser, create a new repository named `OP-Trader-AI` (Public or Private).
4. Upload the contents of the extracted project folder, including `.github/workflows/build-apk.yml`.
5. Open the repository's **Actions** tab and select **Build OP TRADER AI APK**. Tap **Run workflow** if it has not started automatically.
6. Wait for the run to finish successfully. Open the completed run, scroll to **Artifacts**, and download `OP-Trader-AI-debug-apk`.
7. Extract that artifact ZIP on your phone. Tap `app-debug.apk` and allow your browser/file manager to install apps from that source if Android asks.

The workflow builds a debug APK in GitHub's cloud. It is not a pre-tested release APK. Install only after a successful build. Android may show a warning because the APK is not distributed through Play Store.

If GitHub's upload interface hides the `.github` folder, use GitHub's web editor to create `.github/workflows/build-apk.yml` and paste the workflow file from the extracted project.
