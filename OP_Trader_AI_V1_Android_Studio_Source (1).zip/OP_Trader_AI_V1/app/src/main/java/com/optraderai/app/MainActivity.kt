package com.optraderai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import java.text.DecimalFormat

data class TradeRecord(val asset: String, val side: String, val result: String, val note: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OPTraderApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OPTraderApp() {
    val assets = listOf("EUR/USD", "GBP/USD", "USD/JPY", "BTC/USD", "ETH/USD", "AAPL", "TSLA", "GOLD", "SILVER", "OIL", "OTC EUR/USD", "OTC GBP/USD")
    var asset by remember { mutableStateOf(assets.first()) }
    var market by remember { mutableStateOf("Real Market") }
    var timeframe by remember { mutableStateOf("1 minute") }
    var expandedAsset by remember { mutableStateOf(false) }
    var expandedMarket by remember { mutableStateOf(false) }
    var expandedTime by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var analysis by remember { mutableStateOf(AnalysisEngine.analyze(AnalysisEngine.demoCandles())) }
    val trades = remember { mutableStateListOf<TradeRecord>() }
    val df = remember { DecimalFormat("0.00000") }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF55D6A2), secondary = Color(0xFF6DA9FF),
        background = Color(0xFF0B1118), surface = Color(0xFF121C27)
    )) {
        Scaffold(
            containerColor = Color(0xFF0B1118),
            topBar = {
                TopAppBar(
                    title = { Column { Text("OP TRADER AI", style = MaterialTheme.typography.titleLarge); Text("Personal market analysis", style = MaterialTheme.typography.labelSmall, color = Color.LightGray) } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF121C27), titleContentColor = Color.White)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF121C27)) {
                    listOf("Analyze", "Journal", "About").forEachIndexed { index, label ->
                        NavigationBarItem(selected = tab == index, onClick = { tab = index }, icon = {}, label = { Text(label) })
                    }
                }
            }
        ) { padding ->
            when (tab) {
                0 -> AnalyzeScreen(
                    modifier = Modifier.padding(padding), assets, asset, { expandedAsset = it }, expandedAsset, { asset = it },
                    market, { expandedMarket = it }, expandedMarket, { market = it },
                    timeframe, { expandedTime = it }, expandedTime, { timeframe = it },
                    analysis, { analysis = AnalysisEngine.analyze(AnalysisEngine.demoCandles(seed = asset.hashCode() + timeframe.hashCode())) },
                    { result -> trades.add(0, TradeRecord(asset, analysis.direction, result, "Recorded manually. Review the setup explanation above.")) }
                )
                1 -> JournalScreen(Modifier.padding(padding), trades)
                else -> AboutScreen(Modifier.padding(padding))
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyzeScreen(
    modifier: Modifier, assets: List<String>, asset: String, setAssetExpanded: (Boolean) -> Unit, assetExpanded: Boolean, setAsset: (String) -> Unit,
    market: String, setMarketExpanded: (Boolean) -> Unit, marketExpanded: Boolean, setMarket: (String) -> Unit,
    timeframe: String, setTimeExpanded: (Boolean) -> Unit, timeExpanded: Boolean, setTimeframe: (String) -> Unit,
    analysis: Analysis, refresh: () -> Unit, record: (String) -> Unit
) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF172535))) {
            Column(Modifier.padding(16.dp)) {
                Text("MARKET SETUP", color = Color(0xFF55D6A2), style = MaterialTheme.typography.labelLarge)
                ExposedDropdownMenuBox(expanded = assetExpanded, onExpandedChange = setAssetExpanded) {
                    OutlinedTextField(value = asset, onValueChange = {}, readOnly = true, label = { Text("Asset") }, modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = assetExpanded, onDismissRequest = { setAssetExpanded(false) }) {
                        assets.forEach { DropdownMenuItem(text = { Text(it) }, onClick = { setAsset(it); setAssetExpanded(false) }) }
                    }
                }
                ExposedDropdownMenuBox(expanded = marketExpanded, onExpandedChange = setMarketExpanded) {
                    OutlinedTextField(value = market, onValueChange = {}, readOnly = true, label = { Text("Market type") }, modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = marketExpanded, onDismissRequest = { setMarketExpanded(false) }) {
                        listOf("Real Market", "OTC (demo only)").forEach { DropdownMenuItem(text = { Text(it) }, onClick = { setMarket(it); setMarketExpanded(false) }) }
                    }
                }
                ExposedDropdownMenuBox(expanded = timeExpanded, onExpandedChange = setTimeExpanded) {
                    OutlinedTextField(value = timeframe, onValueChange = {}, readOnly = true, label = { Text("Timeframe") }, modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = timeExpanded, onDismissRequest = { setTimeExpanded(false) }) {
                        listOf("1 minute", "5 minutes").forEach { DropdownMenuItem(text = { Text(it) }, onClick = { setTimeframe(it); setTimeExpanded(false) }) }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Button(onClick = refresh, modifier = Modifier.fillMaxWidth()) { Text("RUN ANALYSIS") }
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF172535))) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("SIGNAL RESULT", color = Color.LightGray, style = MaterialTheme.typography.labelLarge)
                Text(analysis.direction, color = when (analysis.direction) { "BUY" -> Color(0xFF55D6A2); "SELL" -> Color(0xFFFF7777); else -> Color(0xFFFFC857) }, style = MaterialTheme.typography.headlineLarge)
                Text("Setup quality score: ${analysis.score}/100", color = Color.White)
                LinearProgressIndicator(progress = { analysis.score / 100f }, modifier = Modifier.fillMaxWidth())
                Text("Asset: $asset  •  $market  •  $timeframe", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                Text("Demo data only — no live prices are connected.", color = Color(0xFFFFC857), style = MaterialTheme.typography.labelMedium)
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF172535))) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("INDICATOR VALUES", color = Color(0xFF55D6A2), style = MaterialTheme.typography.labelLarge)
                Metric("EMA 9", analysis.ema9); Metric("EMA 21", analysis.ema21); Metric("EMA 50", analysis.ema50)
                Metric("RSI (14)", analysis.rsi); Metric("MACD", analysis.macd); Metric("ATR (14)", analysis.atr)
            }
        }
        ExplanationCard("WHY THIS SIGNAL?", analysis.reasons)
        ExplanationCard("RISK & CAUTIONS", analysis.warnings)

        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF172535))) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("RECORD TRADE RESULT", color = Color(0xFF55D6A2), style = MaterialTheme.typography.labelLarge)
                Text("After you independently place or simulate a trade, record its outcome for your journal.")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { record("WIN") }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF167A55))) { Text("WIN") }
                    Button(onClick = { record("LOSS") }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9D3E48))) { Text("LOSS") }
                }
                OutlinedButton(onClick = { record("BREAKEVEN") }, modifier = Modifier.fillMaxWidth()) { Text("BREAKEVEN") }
            }
        }
    }
}

@Composable
fun Metric(label: String, value: Double) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Color.LightGray)
        Text(String.format("%.5f", value), color = Color.White)
    }
}

@Composable
fun ExplanationCard(title: String, lines: List<String>) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF172535))) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, color = Color(0xFF55D6A2), style = MaterialTheme.typography.labelLarge)
            lines.forEach { Text("• $it", color = Color.White, style = MaterialTheme.typography.bodyMedium) }
        }
    }
}

@Composable
fun JournalScreen(modifier: Modifier, trades: List<TradeRecord>) {
    val wins = trades.count { it.result == "WIN" }
    val losses = trades.count { it.result == "LOSS" }
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("TRADE JOURNAL", color = Color.White, style = MaterialTheme.typography.headlineSmall)
        Text("Recorded: ${trades.size}  •  Wins: $wins  •  Losses: $losses", color = Color(0xFF55D6A2))
        if (trades.isEmpty()) Text("No trades recorded yet. Analyze a setup and record its result.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(trades) { trade ->
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF172535))) {
                    Column(Modifier.padding(12.dp)) {
                        Text("${trade.asset} • ${trade.side}", color = Color.White)
                        Text("Result: ${trade.result}", color = if (trade.result == "WIN") Color(0xFF55D6A2) else Color(0xFFFFC857))
                        Text(trade.note, color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
fun AboutScreen(modifier: Modifier) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("ABOUT OP TRADER AI", color = Color.White, style = MaterialTheme.typography.headlineSmall)
        Text("Version 1.0 — local prototype", color = Color(0xFF55D6A2))
        Text("This build uses deterministic demonstration candles. It does not connect to Quotex, exchanges, broker feeds, or the internet.")
        Text("The BUY / SELL / WAIT output is a rule-based educational signal. The setup score is not a win probability.")
        Text("OTC markets may use broker-generated prices. Do not treat real-market data as a substitute for the broker's OTC feed.")
        Text("No automatic trade execution is included. Validate strategies with historical data and a demo account before risking money.")
        Text("Trade journal entries are currently kept in app memory and may reset when the app is closed. Persistent storage and full post-trade diagnostics are planned for the next iteration.")
    }
}
