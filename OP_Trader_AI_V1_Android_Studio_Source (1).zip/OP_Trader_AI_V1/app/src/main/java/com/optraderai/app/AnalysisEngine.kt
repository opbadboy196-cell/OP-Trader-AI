package com.optraderai.app

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class Candle(val open: Double, val high: Double, val low: Double, val close: Double)

data class Analysis(
    val direction: String,
    val score: Int,
    val ema9: Double,
    val ema21: Double,
    val ema50: Double,
    val rsi: Double,
    val macd: Double,
    val atr: Double,
    val reasons: List<String>,
    val warnings: List<String>
)

object AnalysisEngine {
    // Deterministic demo candles. These are NOT live broker prices.
    fun demoCandles(seed: Int = 7, count: Int = 100): List<Candle> {
        var x = seed.toLong()
        fun next(): Double {
            x = (x * 1103515245 + 12345) and 0x7fffffff
            return x.toDouble() / 0x7fffffff
        }
        var price = 1.085
        val out = mutableListOf<Candle>()
        repeat(count) {
            val drift = if (it % 30 < 18) 0.00012 else -0.00007
            val change = (next() - 0.49) * 0.0012 + drift
            val close = max(0.01, price + change)
            val open = price
            val wick = next() * 0.00035
            out += Candle(open, max(open, close) + wick, min(open, close) - wick * 0.8, close)
            price = close
        }
        return out
    }

    private fun ema(values: List<Double>, period: Int): Double {
        if (values.isEmpty()) return 0.0
        val alpha = 2.0 / (period + 1.0)
        return values.drop(1).fold(values.first()) { acc, v -> alpha * v + (1 - alpha) * acc }
    }

    private fun rsi(values: List<Double>, period: Int = 14): Double {
        if (values.size <= period) return 50.0
        val changes = values.zipWithNext { a, b -> b - a }.takeLast(period)
        val gains = changes.filter { it > 0 }.sum() / period
        val losses = -changes.filter { it < 0 }.sum() / period
        if (losses == 0.0) return 100.0
        val rs = gains / losses
        return 100.0 - 100.0 / (1.0 + rs)
    }

    fun analyze(candles: List<Candle>): Analysis {
        val closes = candles.map { it.close }
        val e9 = ema(closes.takeLast(60), 9)
        val e21 = ema(closes.takeLast(80), 21)
        val e50 = ema(closes, 50)
        val rsi = rsi(closes)
        val macd = ema(closes, 12) - ema(closes, 26)
        val atr = candles.takeLast(14).map { it.high - it.low }.average()
        val last = candles.last()
        val previous = candles[candles.lastIndex - 1]
        val bullishEngulf = last.close > last.open && previous.close < previous.open &&
            last.close > previous.open && last.open < previous.close
        val bearishEngulf = last.close < last.open && previous.close > previous.open &&
            last.close < previous.open && last.open > previous.close

        var points = 0
        val reasons = mutableListOf<String>()
        val warnings = mutableListOf<String>()

        if (e9 > e21) { points += 2; reasons += "EMA 9 is above EMA 21 (short-term bullish trend)." }
        else { points -= 2; reasons += "EMA 9 is below EMA 21 (short-term bearish trend)." }
        if (e21 > e50) { points += 2; reasons += "EMA 21 is above EMA 50 (broader trend bullish)." }
        else { points -= 2; reasons += "EMA 21 is below EMA 50 (broader trend bearish)." }

        when {
            rsi in 52.0..68.0 -> { points++; reasons += "RSI is in a positive momentum zone." }
            rsi in 32.0..48.0 -> { points--; reasons += "RSI is in a negative momentum zone." }
            rsi >= 70 -> warnings += "RSI is overbought; avoid chasing a late move."
            rsi <= 30 -> warnings += "RSI is oversold; downside may be extended."
            else -> warnings += "RSI is neutral; momentum confirmation is limited."
        }
        if (macd > 0) { points++; reasons += "MACD is positive." }
        else { points--; reasons += "MACD is negative." }
        if (bullishEngulf) { points += 2; reasons += "Bullish engulfing pattern detected." }
        if (bearishEngulf) { points -= 2; reasons += "Bearish engulfing pattern detected." }
        if (!bullishEngulf && !bearishEngulf) warnings += "No engulfing confirmation on the latest candle."
        if (atr <= 0.0) warnings += "ATR unavailable; volatility filter cannot be assessed."

        val direction = when {
            points >= 4 -> "BUY"
            points <= -4 -> "SELL"
            else -> "WAIT"
        }
        val score = (50 + points * 6).coerceIn(0, 100)
        if (direction == "WAIT") warnings += "Signals are mixed. Waiting is preferable to forcing a trade."
        warnings += "This is a rule-based setup score, NOT a probability or guarantee of winning."
        return Analysis(direction, score, e9, e21, e50, rsi, macd, atr, reasons, warnings)
    }
}
